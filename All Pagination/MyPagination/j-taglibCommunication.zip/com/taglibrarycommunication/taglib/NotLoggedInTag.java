package com.taglibrarycommunication.taglib;

import java.io.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;


public class NotLoggedInTag extends BodyTagSupport {

public int doStartTag() {
	return EVAL_BODY_TAG;
}

public int doEndTag() throws JspException {

	// THIS LINE ACCESSES THE PARENT CLASS NestedLoginTag
	NestedLoginTag parent = (NestedLoginTag) getParent();

	if (parent != null){
		BodyContent bc = getBodyContent();
		String body = bc.getString();

		// SET THE notLoggedInHTML PROPERTY OF THE PARENT CLASS
		// WITH THE BODY SUPPLIED THROUGH THE CUSTOM TAG
		parent.setNotLoggedInHTML(body);
	}
	
	return SKIP_BODY;
}

}
