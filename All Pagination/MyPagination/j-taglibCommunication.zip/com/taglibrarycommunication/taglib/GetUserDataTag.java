package com.taglibrarycommunication.taglib;

import java.io.*;
import javax.servlet.jsp.*;
import javax.servlet.http.*;
import javax.servlet.jsp.tagext.*;


public class GetUserDataTag extends TagSupport {

	String _userName = "";
	String _loginError = "";
	HttpSession session;
	
public int doStartTag() {

	session = pageContext.getSession();
	session.removeAttribute("user"); 
	
	// UNCOMMENT TO MIMIC A LOGGED IN USER STORED IN SESSION
	//session.setAttribute("user","John Q. Citizen");

	// UNCOMMENT TO MIMIC LOGIN ERROR STORED IN REQUEST
	//pageContext.getRequest().setAttribute("loginError","Password incorrect");

	if (session.getAttribute("user") != null){
		setUserName(session.getAttribute("user").toString());
	}

	if (pageContext.getRequest().getAttribute("loginError") != null &&
		pageContext.getRequest().getAttribute("loginError") != ""){
		setLoginError(pageContext.getRequest().getAttribute("loginError").toString());
	}

	// THIS IS THE LINE THAT SAVES THIS CLASS TO pageContext
	pageContext.setAttribute(id,this);

	return SKIP_BODY;
}
public int doEndTag() throws JspException {
	return EVAL_PAGE;
}

public String getUserName(){
	return _userName;
}
public String getLoginError(){
	return _loginError;
}
public void setUserName(String userName){
	_userName = userName;
}
public void setLoginError(String loginError){
	_loginError = loginError;
}
}
