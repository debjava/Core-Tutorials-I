package com.taglibrarycommunication.taglib;

import java.io.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;


public class GetLoginErrorTag extends TagSupport {

	private String _userDataID;

public int doStartTag() {
	return SKIP_BODY;
}
public int doEndTag() throws JspException {

	// GET userData OBJECT STORED IN THE pageContext 
	// WITH THE ID PASSED IN THROUGH THE CUSTOM TAG
	GetUserDataTag userData = (GetUserDataTag) pageContext.getAttribute(getUserDataID());

	try{
		if (userData.getLoginError() !=null){
			pageContext.getOut().print(userData.getLoginError());
		}
	} catch (IOException ioe) {
		System.out.println ("Error: " + ioe.getMessage());
	}
	
	return SKIP_BODY;
}

public String getUserDataID(){
	return _userDataID;
}
public void setUserDataID(String userDataID){
	_userDataID = userDataID;
}
}
