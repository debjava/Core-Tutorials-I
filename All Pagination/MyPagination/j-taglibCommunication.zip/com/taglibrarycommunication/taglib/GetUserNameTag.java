package com.taglibrarycommunication.taglib;

import javax.servlet.http.*;
import java.io.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;


public class GetUserNameTag extends TagSupport {

	private String _userName = "";
	private String _userDataID;

public int doEndTag() throws JspException {

	GetUserDataTag userData = (GetUserDataTag) pageContext.getAttribute(getUserDataID());

	try{
		if (userData.getUserName() !=null){
			pageContext.getOut().print(userData.getUserName());
		}
	} catch (IOException ioe) {
		System.out.println ("Error: " + ioe.getMessage());
	}
	
	return SKIP_BODY;
}
public int doStartTag() {
	return SKIP_BODY;
}
public String getUserDataID(){
	return _userDataID;
}
public void setUserDataID(String userDataID){
	_userDataID = userDataID;
}
}
