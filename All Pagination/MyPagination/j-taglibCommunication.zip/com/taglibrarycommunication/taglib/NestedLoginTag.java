package com.taglibrarycommunication.taglib;

import javax.servlet.http.*;
import java.io.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;


public class NestedLoginTag extends BodyTagSupport {

	private String _userDataID;
	private String _userName;
	private String _loginError;

	private String _notLoggedInHTML = "";
	private String _isLoggedInHTML = "";
	private String _logInFailureHTML = "";

	HttpSession session;
	
public int doStartTag() {

	// PULL THE userData OUT OF THE pageContext WITH THE userDataID SUPLLIED THROUGH THE CUSTOM TAG
	GetUserDataTag userData = (GetUserDataTag) pageContext.getAttribute(getUserDataID());

	// SET userName AND loginError FROM VALUES IN userData OBJECT
	setUserName(userData.getUserName());
	setLoginError(userData.getLoginError());

	return EVAL_BODY_TAG;
}

public int doEndTag() throws JspException {

	try{
		if (getUserName()!="" &&
			getLoginError()==""){
			// IF userName IS SET PERSON IS LOGGED IN
			pageContext.getOut().print(getIsLoggedInHTML());
		} else {
			if (getLoginError()=="")
				// IF NO userName SET BUT NO loginError SHOW LOGIN
				pageContext.getOut().print(getNotLoggedInHTML());
			else
				// IF loginError SHOW LOGIN AND ERROR
				pageContext.getOut().print(getLogInFailureHTML());
		}
	} catch (IOException ioe) {
		System.out.println ("Error: " + ioe.getMessage());
	}
	
	return SKIP_BODY;
}

public String getUserDataID(){
	return _userDataID;
}
public String getUserName(){
	return _userName;
}
public String getLoginError(){
	return _loginError;
}
public String getIsLoggedInHTML(){
	return _isLoggedInHTML;
}
public String getLogInFailureHTML(){
	return _logInFailureHTML;
}
public String getNotLoggedInHTML(){
	return _notLoggedInHTML;
}
public void setUserDataID(String userDataID){
	_userDataID = userDataID;
}
public void setUserName(String userName){
	_userName = userName;
}
public void setLoginError(String loginError){
	_loginError = loginError;
}
public void setIsLoggedInHTML(String isLoggedInHTML){
	_isLoggedInHTML = isLoggedInHTML;
}
public void setLogInFailureHTML(String logInFailureHTML){
	_logInFailureHTML = logInFailureHTML;
}
public void setNotLoggedInHTML(String notLoggedInHTML){
	_notLoggedInHTML = notLoggedInHTML;
}
}
